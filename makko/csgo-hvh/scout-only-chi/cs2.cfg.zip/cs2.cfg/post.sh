#!/bin/bash

# POST HOOK
#  Make your customisation here
echo "post-hook: noop"
