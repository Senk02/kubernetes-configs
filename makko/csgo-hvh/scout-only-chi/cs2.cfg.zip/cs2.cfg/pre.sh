#!/bin/bash

# PRE HOOK
#  Make your customisation here
echo "pre-hook: noop"
